

class FindColumns {
    constructor() {
        this.ColumnNumber = new Number();
        this.ColumnAlias = new String();
        this.ColumnDescription = new String();
        this.Code = new String();
    }
    ColumnNumber;
    ColumnAlias;
    ColumnDescription;
    Code;

}

module.exports = FindColumns;