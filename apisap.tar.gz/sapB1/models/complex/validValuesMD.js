

class ValidValuesMD {
    constructor() {
        this.Value = new String();
        this.Description = new String();
    }
    Value;
    Description;
}

module.exports = ValidValuesMD;