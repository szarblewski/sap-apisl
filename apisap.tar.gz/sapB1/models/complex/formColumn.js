

class FormColumn {
    constructor() {
        this.FormColumnAlias = new String();
        this.FormColumnDescription = new String();
        this.FormColumnNumber = new Number();
        this.SonNumber = new Number();
        this.Code = new String();
        this.Editable = new String();
    }
    FormColumnAlias;
    FormColumnDescription;
    FormColumnNumber;
    SonNumber;
    Code;
    Editable;

}

module.exports = FormColumn;