

class ChildTable {
    constructor(){
        this.SonNumber = new Number();
        this.TableName = new String();
        this.LogTableName = new String();
        this.Code = new String();
        this.ObjectName = new String();
    }
    SonNumber;
    TableName;
    LogTableName;
    Code;
    ObjectName;

}

module.exports = ChildTable;