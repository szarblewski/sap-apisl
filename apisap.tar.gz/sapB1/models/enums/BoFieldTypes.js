const BoFieldTypes = {
    db_Alpha: 'db_Alpha',
    db_Memo: 'db_Memo',
    db_Numeric: 'db_Numeric',
    db_Date: 'db_Date',
    db_Float: 'db_Float',
};

module.exports = BoFieldTypes;