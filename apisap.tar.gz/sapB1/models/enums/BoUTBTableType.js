const BoUTBTableType = {
    bott_DocumentLines: 'bott_DocumentLines',
    bott_MasterDataLines: 'bott_MasterDataLines',
    bott_NoObject: 'bott_NoObject',
    bott_NoObjectAutoIncrement: 'bott_NoObjectAutoIncrement',
    bott_MasterData: 'bott_MasterData',
    bott_Document: 'bott_Document', 

}

module.exports = BoUTBTableType;
