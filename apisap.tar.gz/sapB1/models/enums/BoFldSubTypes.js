const BoFldSubTypes = {
    st_Percentage: 'st_Percentage',
    st_Sum: 'st_Sum',
    st_Quantity: 'st_Quantity',
    st_Image: 'st_Image',
    st_Link: 'st_Link',
    st_Measurement: 'st_Measurement',
    st_None: 'st_None',
    st_Price: 'st_Price',
    st_Address: 'st_Address',
    st_Time: 'st_Time',
    st_Phone: 'st_Phone',
    st_Rate: 'st_Rate',
}

module.exports = BoFldSubTypes;