const BoYesNo = {
    tNO: 'tNO',
    tYES: 'tYES',
}

module.exports = BoYesNo;