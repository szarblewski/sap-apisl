
class UserTablesMD {
    constructor() {
        this.TableName = new String();
        this.TableDescription = new String();
        this.TableType = new String();
        this.Archivable = new String();
        this.ArchiveDateField = new String();
        this.sapObjectName = 'UserTablesMD';
    }
    TableName;
    TableDescription;
    TableType;
    Archivable;
    ArchiveDateField;
        
    

}


module.exports = UserTablesMD;